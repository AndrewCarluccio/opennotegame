#ifndef TWEENPARAM_H
#define TWEENPARAM_H
#include "TweenableParams.h"
#include <time.h>  
using namespace std;

class TweenParam {

public:
    TweenParam(string paramToTween, double startVal, double endVal, double time);
    string getParam();
    double getStartVal();
    double getEndVal();
    double getTweenTime();
    double getStartTime();
    
private:
    string param;
    double startVal;
    double endVal;
    double tweenTime;
    time_t startTime;
};

#endif