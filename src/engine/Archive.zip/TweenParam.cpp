#include "TweenParam.h"

TweenParam::TweenParam(TweenableParams* paramToTween, double startVal, double endVal, double tweenTime) {
    this->param = paramToTween;
    this->startVal = startVal;
    this->endVal =  endVal;
    this->tweenTime = tweenTime;
    this->startTime = time(nullptr);
}
TweenableParams* TweenParam::getParam(){
    return this->param;
}
double TweenParam::getStartVal(){
    return this->startVal;
}
double TweenParam::getEndVal(){
    return this->endVal;
}
double TweenParam::getTweenTime(){
    return this->tweenTime;
}
double TweenParam::getStartTime(){
    return this->startTime;
}